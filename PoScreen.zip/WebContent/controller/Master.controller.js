sap.ui.define( [
		"jquery.sap.global",
		"z_inbox/controller/BaseController", 
		"z_inbox/model/formatter",
		"sap/ui/Device"
	], function (jQuery, Controller, formatter, Device) {
	"use strict";

	return Controller.extend("z_inbox.controller.Master", {
		formatter : formatter,
		onInit : function () {
			this.getOwnerComponent().getRouter().getRoute("master").attachPatternMatched(this._onRouteMatched, this);
			var abc = [{
                "Banfn":"1000001247",
                "State":"Warning",
                "Status":"Submitted",
                "Title2":"Urgent",
                "Title3":"22-Nov-2018",
                "Title4":"Pending Verification",
                "Title1":"English PR Recording"
               
            },{
            "Banfn":"1000001248",
                "State":"Success",
                "Status":"Approved",
                "Title2":"Urgent",
                "Title3":"19-Nov-2018",
                "Title4":"Awaiting Purchase Order",
                "Title1":"Disable Installment"
            },{
            "Banfn":"1000001249",
                "State":"Warning",
                "Status":"Submitted",
                "Title2":"Urgent",
                "Title3":"08-Nov-2018",
                "Title4":"Pending Verification",
                "Title1":"Change VAT"
            }
                ];
               
                var oModel = new sap.ui.model.json.JSONModel(abc);
                this.getView().setModel(oModel);
			/*var serviceUrl = srcUrlHelper("/sap/bc/ui2/start_up");
			var that = this;*/
			
		},
		_onRouteMatched: function(oEvent) {
			
			if(!Device.system.phone) {
				this.getOwnerComponent().getRouter()
					.navTo("welcome");				
			}
		},
		onPressPO:function(evt){
			this.getView().byId("pageID").setTitle("Purchase Order");	
		},
		onPressDN:function(evt){
		//	evt.getSource().getText()
			this.getView().byId("pageID").setTitle(evt.getSource().getText());
		},
		onPressWO:function(){
			/*	this.getOwnerComponent().getRouter()
					.navTo("createWo");	*/
				
				this.getOwnerComponent().getRouter()
					.navTo("dispVendor");	
					/*	this.getOwnerComponent().getRouter()
					.navTo("invChagneDisp");*/
		},
		onWorkItemSelection:function(oEvent){/*
			
		var SAP__Origin =	oEvent.getSource().getBindingContext().getProperty("SAP__Origin");
		var workItem =	oEvent.getSource().getBindingContext().getProperty("InstanceID");
			
			this.getOwnerComponent().getRouter()
			.navTo("workFlow",{wfId: workItem,origin:SAP__Origin});	
			
		*/
		var uId  = oEvent.getSource().getBindingContext().getProperty("Banfn");
		this.getRouter().navTo("PRdisplay",{id : uId});
		//	var uId  = oEvent.getSource().getBindingContext().getProperty("Instid");
		//	var wiid  = oEvent.getSource().getBindingContext().getProperty("Wiid");
		//	var appType  = oEvent.getSource().getBindingContext().getProperty("WfTask");
//			var uId = "PC41EADD25";
			
		/*	if(appType == "PC"){
				this.getRouter().navTo("Pettycash",    {id : uId,instId : wiid});
			}else if(appType == "RE"){
				this.getRouter().navTo("RewardsApprn", {id : uId,instId : wiid});
			}else if(appType == "EC"){
				this.getRouter().navTo("ExpenseClaim", {id : uId,instId : wiid});
			}else if(appType == "PR"){
				this.getRouter().navTo("PurchaseReq",  {id : uId,instId : wiid});	
			}else if(appType == "CR"){
				this.getRouter().navTo("CreditCard",   {id : uId,instId : wiid});	
			}else if(appType == "QR"){
				this.getRouter().navTo("QR",           {id : uId,instId : wiid});	
			}else if(appType == "IV"){
				this.getRouter().navTo("Invoice",      {id : uId,instId : wiid});	
			}else if(appType == "PO"){
				this.getRouter().navTo("poAmmendment", {id : uId,instId : wiid});	
			}*/
			
			
//			var oModel = this.getView().getModel();
		
	/*	var sPath = "/WF_UIAPPROVALSet(WiAagent='"+this.userId+"',Wiid='"+wiid+"',Decision='Y')";
			oModel.read(sPath,{
				success:function(oData){
					 this.getView().getModel().refresh();
					
				}.bind(this)
				
			});*/
			
		
		},
		
		
	onBeforeRendering:function(){
	
		/*
			
		var inbx = this.getView().byId("inbox_app");
//		var oBinding = inbx.getBinding("items");
		
		var aFilters = [];

		
//	    aFilters.push( new sap.ui.model.Filter("WiAagent", "EQ", this.userId) );
//	    aFilters.push( new sap.ui.model.Filter("WiRhTask", "EQ", "TS00008267") );
//	    aFilters.push( new sap.ui.model.Filter("WfTask", "EQ", "WS90000007") );
		
		inbx.bindItems("/WORKITEMSSet",new sap.m.StandardListItem({text:"hello"}),aFilters);
		
		inbx.bindItems({
			path:"/WORKITEMSSet",
			   filters: new sap.ui.model.Filter(aFilters, true),
			   template : new sap.m.StandardListItem({

                   title : '{WfTask}',

                   type : sap.m.ListType.Active,

                   description : "{WiText}",

                   tap :[this.handleListItemPress,this]

         })
		});
		
		
		
//		oBinding.filter(aFilters,"Application"); 
		
//		inbx.bindItems("/WORKITEMSSet",);
		
			
			
		*/
		
	}
		
	});

}, /* bExport= */ true);