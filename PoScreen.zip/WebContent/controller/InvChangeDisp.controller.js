sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/Label',
	'sap/m/MessageToast',
	'sap/m/Text',
	'sap/m/TextArea'
], function(Controller,Button, Dialog, Label, MessageToast, Text, TextArea) {
	"use strict";

	return Controller.extend("z_inbox.controller.InvChangeDisp", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf z_inbox.WebContent.view.InvChangeDisp
		 */
		//	onInit: function() {
		//
		//	},
		onApprove:function(){
			if(!this.oDialog){
				this.oDialog=sap.ui.xmlfragment("z_inbox.view.fragments.Approve",this);	
			}
			this.oDialog.open();
		},
		handleReject: function () {
	var that = this;
	var dialog = new Dialog({
		title: "Reject",
		type: 'Message',
		content: [
			new Label({ text: "Reject Confirmation", labelFor: 'submitDialogTextarea'}),
			new TextArea('submitDialogTextarea', {
				liveChange: function(oEvent) {
					var sText = oEvent.getParameter('value');
					var parent = oEvent.getSource().getParent();

					parent.getBeginButton().setEnabled(sText.length > 0);
				},
				width: '100%',
				placeholder: "MandatoryNote"
			})
		],
		beginButton: new Button({
			text: "Submit",
			enabled: false,
			press: function () {
				var sText = sap.ui.getCore().byId('submitDialogTextarea').getValue();
				that._onPRReject(sText, that);
				dialog.close();
			}
		}),
		endButton: new Button({
			text: "Cancel",
			press: function () {
				dialog.close();
			}
		}),
		afterClose: function() {
			dialog.destroy();
		}
	});

	dialog.open();
}
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf z_inbox.WebContent.view.InvChangeDisp
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf z_inbox.WebContent.view.InvChangeDisp
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf z_inbox.WebContent.view.InvChangeDisp
		 */
		//	onExit: function() {
		//
		//	}

	});

});