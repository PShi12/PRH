sap.ui.controller("z_inbox.controller.welcome", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf prinbox.app
*/
	onInit: function() {
		var abc = [{
                "Banfn":"1000001247",
                "State":"Warning",
                "Request":"Nick",
                "Status":"Submitted",
                "Title2":"Urgent",
                "Title3":"22-Nov-2018",
                "Title4":"Pending Verification",
                "totVal":"12321",
                "Curr":"USD",
                "suppDetail":"120987 MK Traders",
                "Title1":"English PR Recording"
               
            },{
            "Banfn":"1000001247",
                "State":"Success",
                "Request":"Ponting",
                "Status":"Approved",
                "Title2":"Urgent",
                "totVal":"12321",
                "Curr":"USD",
                "suppDetail":"120987 MK Traders",
                "Title3":"19-Nov-2018",
                "Title4":"Awaiting Purchase Order",
                "Title1":"Disable Installment"
            },{
            "Banfn":"1000001247",
                "State":"Warning",
                "Status":"Submitted",
                "Request":"Crist",
                "totVal":"12321",
                "Curr":"USD",
                "suppDetail":"120987 MK Traders",
                "Title2":"Urgent",
                "Title3":"08-Nov-2018",
                "Title4":"Pending Verification",
                "Title1":"Change VAT"
            }
                ];
               
                var oModel = new sap.ui.model.json.JSONModel(abc);
                this.getView().setModel(oModel);
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf prinbox.app
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf prinbox.app
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf prinbox.app
*/
//	onExit: function() {
//
//	}
	onNavBack: function() {
		this.getOwnerComponent().getRouter().navTo("master", {},true);
//		var sPreviousHash = sap.ui.core.routing.History.getInstance().getPreviousHash();
//		// The history contains a previous entry
//		if (sPreviousHash !== undefined) {
//			history.go(-1);
//		} else {
//			// There is no history!
//			// Navigate to master page
//			this.getOwnerComponent().getRouter().navTo("master", {},true);
//		}
	}
});