/*global QUnit*/

sap.ui.define([
	"AMSMONITOR/ZAMSMONITOR_PAYMENTUPDATE/controller/PaymentUpdate.controller"
], function (Controller) {
	"use strict";

	QUnit.module("PaymentUpdate Controller");

	QUnit.test("I should test the PaymentUpdate controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});