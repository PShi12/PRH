sap.ui.define([
	"AMSMONITOR/ZAMSMONITOR_PAYMENTUPDATE/test/unit/controller/PaymentUpdate.controller"
], function () {
	"use strict";
});