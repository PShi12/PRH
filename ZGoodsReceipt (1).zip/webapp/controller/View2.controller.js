sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"ZDashboard/model/formatter",
	"sap/m/MessageBox"
], function(Controller, formatter, MessageBox) {
	"use strict";
	return Controller.extend("ZDashboard.controller.View2", {
		formatter: formatter,
		onInit: function() {
			var payment =  [
		{
			"title": "Notebook HT",
			"subtitle": "ID23452256-D44",
			"revenue": "27.25K EUR",
			"status": "success",
			"statusSchema": "Success",
			"value":10,
			"icon":"sap-icon://create",
			"t1":"Manage Purchase Requistion",
			"invoice":"12345",
			"amount":"100K USD"
			
		},
		{
			"title": "Notebook XT",
			"subtitle": "ID27852256-D47",
			"revenue": "7.35K EUR",
			"status": "exceeded",
			"statusSchema": "Error",
			"value":70,
				"icon":"sap-icon://sales-order-item",
					"t1":"Manage Purchase orders",
					"invoice":"6789",
			"amount":"500K USD"
		},
		{
			"title": "Notebook ST",
			"subtitle": "ID123555587-I05",
			"revenue": "22.89K EUR",
			"status": "warning",
			"statusSchema": "Warning",
			"value":100,
			"icon":"sap-icon://sales-order",
				"t1":"Manage Post Goods Receipt",
					"invoice":"1122",
			"amount":"89.67K USD"
		},
		
			{
		
				"t1":"Manage Post Invoice",
					"icon":"sap-icon://sales-order"
			
		}
		
	];
	var oModel = new sap.ui.model.json.JSONModel(payment);
	this.getView().setModel(oModel,"ListModel");
	var milk =  [{
        "StoreName": "24-Seven",
        "Revenue": 428214.13,
        "Cost": 94383.52,
        "Consumption": 76855.15368,
        "Country": "China"
    },
    {
        "StoreName": "A&A",
        "Revenue": 1722148.36,
        "Cost": 274735.17,
        "Consumption": 310292.22,
        "Country": "China"
    },
    {
        "StoreName": "Alexei's Specialities",
        "Revenue": 1331176.706884,
        "Cost": 233160.58,
        "Consumption": 143432.18,
        "Country": "China"
    },
    {
        "StoreName": "BC Market",
        "Revenue": 1878466.82,
        "Cost": 235072.19,
        "Consumption": 487910.26,
        "Country": "China"
    }
  
  ];
    	var oModel = new sap.ui.model.json.JSONModel(milk);
	this.getView().setModel(oModel,"LineModel");
	
var donut =  [{
        "StoreName": "24-Seven",
        "Revenue": 428214.13,
        "Cost": 94383.52,
        "Consumption": 76855.15368
    },
    {
        "StoreName": "A&A",
        "Revenue": 1722148.36,
        "Cost": 274735.17,
        "Consumption": 310292.22
    },
    {
        "StoreName": "Alexei's Specialities",
        "Revenue": 1331176.706884,
        "Cost": 233160.58,
        "Consumption": 143432.18
    },
    {
        "StoreName": "BC Market",
        "Revenue": 1878466.82,
        "Cost": 235072.19,
        "Consumption": 487910.26
    },
    {
        "StoreName": "Choices Franchise 1",
        "Revenue": 3326251.94,
        "Cost": 582543.16,
        "Consumption": 267185.27
    },
    {
        "StoreName": "Choices Franchise 3",
        "Revenue": 2090030.97,
        "Cost": 397952.77,
        "Consumption": 304964.8856125
    },
    {
        "StoreName": "Choices Franchise 6",
        "Revenue": 1932991.59,
        "Cost": 343427.25,
        "Consumption": 291191.83
    },
    {
        "StoreName": "Dairy World",
        "Revenue": 752565.16,
        "Cost": 115844.26,
        "Consumption": 98268.9597904
    },
    {
        "StoreName": "Delikatessen",
        "Revenue": 1394072.66,
        "Cost": 263180.86,
        "Consumption": 176502.5521223
    },
    {
        "StoreName": "Donald's Market",
        "Revenue": 3308333.872944,
        "Cost": 611658.59,
        "Consumption": 538515.47632832
    }];
    	var oModel = new sap.ui.model.json.JSONModel(donut);
	this.getView().setModel(oModel,"donutModel");
	
		this.oVizFrame = this.getView().byId("idVizFrame2");
		
		}
	});
});